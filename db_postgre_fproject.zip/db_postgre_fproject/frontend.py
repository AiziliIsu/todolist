import streamlit as st
from database import session
from models import Movie

def main():
    st.title('Movie Information')

    # Query all movies from the database
    movies = session.query(Movie).all()

    # Display movie information
    for movie in movies:
        st.subheader(movie.title)
        # Display other movie information here
        # For example:
        # st.write(f"Release Date: {movie.releases[0].release_date}")

if __name__ == "__main__":
    main()
