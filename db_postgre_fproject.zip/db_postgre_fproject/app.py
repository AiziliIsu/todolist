import streamlit as st
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from models import Movie, Base

# Database URL
DB_URL = "postgresql://dbadmin:new_password@localhost/movie"

# Create engine and session
engine = create_engine(DB_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
session = SessionLocal()

# Title
st.title("Movie Information")

# Query movies with their information
def get_movies():
    movies = session.query(Movie).all()
    return movies

# Display movie information
def display_movies(movies):
    for movie in movies:
        st.subheader(f"Movie: {movie.name}")
        # Display other movie information as needed

if __name__ == "__main__":
    # Create all tables if they don't exist
    Base.metadata.create_all(bind=engine)

    # Query movies
    movies = get_movies()

    # Display movies
    display_movies(movies)
