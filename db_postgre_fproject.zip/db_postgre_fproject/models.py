from sqlalchemy import Column, Integer, String, ForeignKey, Date, Time
from sqlalchemy.orm import relationship
from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()

class Movie(Base):
    __tablename__ = "movie"

    movie_id = Column(Integer, primary_key=True)
    name = Column(String)
    release_id = Column(Integer, ForeignKey("release.release_id"))
    genre_id = Column(Integer, ForeignKey("genre.genre_id"))
    age_limit_id = Column(Integer, ForeignKey("age_limit.age_limit_id"))
    duration_id = Column(Integer, ForeignKey("duration.duration_id"))

    releases = relationship("Release", back_populates="movie", foreign_keys=[release_id])
    genre = relationship("Genre", back_populates="movies")
    age_limit = relationship("AgeLimit", back_populates="movies")
    duration = relationship("Duration", back_populates="movies")

class Release(Base):
    __tablename__ = "release"

    release_id = Column(Integer, primary_key=True)
    release_date = Column(Date)
    movie_id = Column(Integer, ForeignKey("movie.movie_id"))

    movie = relationship("Movie", back_populates="releases", foreign_keys=[movie_id])

class Genre(Base):
    __tablename__ = "genre"

    genre_id = Column(Integer, primary_key=True)
    name = Column(String)

    movies = relationship("Movie", back_populates="genre")

class AgeLimit(Base):
    __tablename__ = "age_limit"

    age_limit_id = Column(Integer, primary_key=True)
    name = Column(String)

    movies = relationship("Movie", back_populates="age_limit")

class Duration(Base):
    __tablename__ = "duration"

    duration_id = Column(Integer, primary_key=True)
    name = Column(String)

    movies = relationship("Movie", back_populates="duration")

class Language(Base):
    __tablename__ = "language"

    language_id = Column(Integer, primary_key=True)
    name = Column(String)

    movie_films = relationship("MovieFilm", back_populates="language")

class Format(Base):
    __tablename__ = "format"

    format_id = Column(Integer, primary_key=True)
    name = Column(String)

    movie_films = relationship("MovieFilm", back_populates="format")

class IMAX(Base):
    __tablename__ = "imax"

    imax_id = Column(Integer, primary_key=True)
    name = Column(String)

    movie_films = relationship("MovieFilm", back_populates="imax")

class MovieFilm(Base):
    __tablename__ = "movie_fil"

    movie_fil_id = Column(Integer, primary_key=True)
    language_id = Column(Integer, ForeignKey("language.language_id"))
    format_id = Column(Integer, ForeignKey("format.format_id"))
    imax_id = Column(Integer, ForeignKey("imax.imax_id"))
    movie_id = Column(Integer, ForeignKey("movie.movie_id"))

    language = relationship("Language", back_populates="movie_films")
    format = relationship("Format", back_populates="movie_films")
    imax = relationship("IMAX", back_populates="movie_films")
    movie = relationship("Movie", back_populates="movie_films")

class Date(Base):
    __tablename__ = "date"

    date_id = Column(Integer, primary_key=True)
    name = Column(Date)

    datetimes = relationship("DateTime", back_populates="date")

class Time(Base):
    __tablename__ = "time"

    time_id = Column(Integer, primary_key=True)
    name = Column(Time)

    datetimes = relationship("DateTime", back_populates="time")

class DateTime(Base):
    __tablename__ = "dtime"

    dtime_id = Column(Integer, primary_key=True)
    date_id = Column(Integer, ForeignKey("date.date_id"))
    time_id = Column(Integer, ForeignKey("time.time_id"))

    date = relationship("Date", back_populates="datetimes")
    time = relationship("Time", back_populates="datetimes")

class Price(Base):
    __tablename__ = "price"

    price_id = Column(Integer, primary_key=True)
    name = Column(Integer)

    movie_datetimes = relationship("MovieDateTime", back_populates="price")

class MovieDateTime(Base):
    __tablename__ = "movie_dtime"

    movie_dtime_id = Column(Integer, primary_key=True)
    movie_fil_id = Column(Integer, ForeignKey("movie_fil.movie_fil_id"))
    dtime_id = Column(Integer, ForeignKey("dtime.dtime_id"))
    price_id = Column(Integer, ForeignKey("price.price_id"))

    movie_fil = relationship("MovieFilm", back_populates="movie_datetimes")
    dtime = relationship("DateTime", back_populates="movie_datetimes")
    price = relationship("Price", back_populates="movie_datetimes")

class Seat(Base):
    __tablename__ = "seat"

    seat_id = Column(Integer, primary_key=True)
    row = Column(Integer)
    number = Column(Integer)

    room_seats = relationship("RoomSeat", back_populates="seat")

class Room(Base):
    __tablename__ = "room"

    room_id = Column(Integer, primary_key=True)
    name = Column(String)

    room_seats = relationship("RoomSeat", back_populates="room")

class Status(Base):
    __tablename__ = "status"

    status_id = Column(Integer, primary_key=True)
    name = Column(String)

    room_seats = relationship("RoomSeat", back_populates="status")

class RoomSeat(Base):
    __tablename__ = "room_seat"

    room_seat_id = Column(Integer, primary_key=True)
    movie_dtime_id = Column(Integer, ForeignKey("movie_dtime.movie_dtime_id"))
    seat_id = Column(Integer, ForeignKey("seat.seat_id"))
    room_id = Column(Integer, ForeignKey("room.room_id"))
    status_id = Column(Integer, ForeignKey("status.status_id"))

    movie_datetime = relationship("MovieDateTime", back_populates="room_seats")
    seat = relationship("Seat", back_populates="room_seats")
    room = relationship("Room", back_populates="room_seats")
    status = relationship("Status", back_populates="room_seats")
