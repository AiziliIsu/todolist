from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from models import Base

# Create an engine
engine = create_engine('sqlite:///movies.db')

# Create tables based on the models
Base.metadata.create_all(engine)

# Create a session
Session = sessionmaker(bind=engine)
session = Session()

# You can now use the 'session' object to interact with the database
